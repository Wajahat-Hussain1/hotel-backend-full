"use client";

export default function AdminStats() {
  // Placeholder values — later replace with API data
  const stats = [
    { title: "Total Bookings", value: "120" },
    { title: "Total Customers", value: "85" },
    { title: "Revenue", value: "$24,500" },
    { title: "Staff Count", value: "12" },
    { title: "Available Rooms", value: "18" },
  ];

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
      {stats.map((s, i) => (
        <div key={i} className="bg-white p-4 rounded-lg shadow">
          <div className="text-sm text-gray-500">{s.title}</div>
          <div className="mt-2 text-2xl font-bold">{s.value}</div>
        </div>
      ))}
    </div>
  );
}
