"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";

export default function AdminSidebar() {
  const pathname = usePathname();

  const items = [
    { name: "Dashboard", href: "/admin/dashboard" },
    { name: "Rooms", href: "/admin/rooms" },
    { name: "Bookings", href: "/admin/bookings" },
    { name: "Customers", href: "/admin/customers" },
    { name: "Payments", href: "/admin/payments" },
    { name: "Staff", href: "/admin/staff" },
    { name: "Settings", href: "/admin/settings" },
  ];

  return (
    <div className="h-full bg-white border-r p-6">
      <div className="mb-6">
        <h2 className="text-xl font-semibold">Admin Panel</h2>
        <p className="text-sm text-gray-500 mt-1">Manage hotel system</p>
      </div>

      <nav className="flex flex-col gap-2">
        {items.map((it) => {
          const active = pathname === it.href;
          return (
            <Link
              key={it.href}
              href={it.href}
              className={`block px-3 py-2 rounded-md text-sm font-medium ${
                active ? "bg-blue-50 text-blue-600" : "text-gray-700 hover:bg-gray-50"
              }`}
            >
              {it.name}
            </Link>
          );
        })}
      </nav>
    </div>
  );
}
