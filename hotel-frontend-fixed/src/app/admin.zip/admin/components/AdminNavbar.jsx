"use client";

import { useRouter } from "next/navigation";

export default function AdminNavbar() {
  const router = useRouter();

  function handleLogout() {
    localStorage.removeItem("hotel_token");
    localStorage.removeItem("hotel_role");
    router.push("/login");
  }

  const adminName = typeof window !== "undefined" ? (localStorage.getItem("hotel_admin_name") || "Admin") : "Admin";

  return (
    <div className="bg-white border-b shadow-sm">
      <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <button
            className="md:hidden px-2 py-1 rounded hover:bg-gray-100"
            onClick={() => {
              // optional: implement mobile sidebar toggle if you want later
            }}
          >
            ☰
          </button>
          <div className="text-lg font-semibold">The Velvet Door — Admin</div>
        </div>

        <div className="flex items-center gap-4">
          <div className="text-sm text-gray-600 hidden sm:block">{adminName}</div>
          <button
            onClick={handleLogout}
            className="px-3 py-2 bg-red-500 text-white rounded hover:bg-red-600"
          >
            Logout
          </button>
        </div>
      </div>
    </div>
  );
}
