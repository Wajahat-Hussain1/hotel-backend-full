"use client";

export default function AdminRecent() {
  const bookings = [
    { id: 1, name: "Alice", room: "Deluxe", date: "2024-12-01" },
    { id: 2, name: "John", room: "Suite", date: "2024-12-02" },
    { id: 3, name: "Mina", room: "Single", date: "2024-12-03" },
  ];

  return (
    <div className="bg-white p-5 rounded-lg shadow">
      <h3 className="text-lg font-medium mb-3">Recent Bookings</h3>
      <ul className="space-y-2">
        {bookings.map((b) => (
          <li key={b.id} className="flex justify-between items-center border-b pb-2">
            <div>
              <div className="font-medium">{b.name}</div>
              <div className="text-sm text-gray-500">{b.room}</div>
            </div>
            <div className="text-sm text-gray-500">{b.date}</div>
          </li>
        ))}
      </ul>
    </div>
  );
}
