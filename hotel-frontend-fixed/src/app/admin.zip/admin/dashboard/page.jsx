"use client";

import { useEffect } from "react";
import { useRouter } from "next/navigation";
import AdminNavbar from "../components/AdminNavbar";
import AdminSidebar from "../components/AdminSidebar";
import AdminStats from "../components/AdminStats";
import AdminRecent from "../components/AdminRecent";

export default function AdminDashboardPage() {
  const router = useRouter();

  useEffect(() => {
    // Simple client-side protection:
    const role = typeof window !== "undefined" ? localStorage.getItem("hotel_role") : null;
    const token = typeof window !== "undefined" ? localStorage.getItem("hotel_token") : null;

    if (!token || role !== "admin") {
      router.push("/"); // not admin -> go to home
    }
  }, [router]);

  return (
    <div className="min-h-screen flex bg-gray-50">
      {/* Sidebar */}
      <aside className="w-64 hidden md:block">
        <AdminSidebar />
      </aside>

      {/* Main Area */}
      <div className="flex-1 flex flex-col">
        <AdminNavbar />

        <main className="p-6">
          <h1 className="text-2xl font-semibold mb-4">Dashboard</h1>

          {/* Stats */}
          <AdminStats />

          {/* Recent */}
          <div className="mt-6 grid grid-cols-1 lg:grid-cols-2 gap-6">
            <AdminRecent />
            {/* placeholder for future widgets */}
            <div className="bg-white p-5 shadow rounded-lg">
              <h2 className="text-lg font-medium mb-2">Quick Actions</h2>
              <div className="flex flex-wrap gap-3">
                <button className="px-3 py-2 bg-blue-600 text-white rounded">Add Room</button>
                <button className="px-3 py-2 bg-green-600 text-white rounded">Add Booking</button>
                <button className="px-3 py-2 bg-yellow-500 text-white rounded">Add Staff</button>
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
